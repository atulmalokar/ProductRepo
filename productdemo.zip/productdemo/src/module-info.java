/**
 * 
 */
/**
 * @author AtulM
 *
 */
module productdemo {
	requires java.sql;
}