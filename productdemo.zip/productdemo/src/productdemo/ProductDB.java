package productdemo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ProductDB {
	Connection con = null;

	public ProductDB() {
		try {
			con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/telusko","postgres","0000");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void save(Product p) {
		String query = "insert into product (name,type,place,warranty) values (?,?,?,?)";
		try {
			PreparedStatement ps = con.prepareStatement(query);
			ps.setString(1, p.getName());
			ps.setString(2, p.getType());
			ps.setString(3, p.getPlace());
			ps.setInt(4, p.getWarranty());
			ps.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public List<Product> getAll() {
		List<Product> products = new ArrayList<Product>();
		String query = "select name,type,place,warranty from product";
		try {
			PreparedStatement ps = con.prepareStatement(query);
			ResultSet rs = ps.executeQuery();
			while(rs.next()) {
				Product p = new Product();
				p.setName(rs.getString(1));
				p.setType(rs.getString(2));
				p.setPlace(rs.getString(3));
				p.setWarranty(rs.getInt(4));
				products.add(p);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return products;
	}
}
;