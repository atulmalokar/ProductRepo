package productdemo;

import java.util.List;

public class Main {

	public static void main(String[] args) {
		ProductService service= new ProductService();
		service.addProduct(new Product("Asus vivobook","Laptop","Brown",2022));
		service.addProduct(new Product("Dell","Desktop","Brown",2021));
		service.addProduct(new Product("HP","Desktop","Red",2022));
		service.addProduct(new Product("Mac black","Desktop","Brown",2020));
		service.addProduct(new Product("Acer","Laptop","Green",2023));
		service.addProduct(new Product("Macbook","Laptop","Black",2022));
		service.addProduct(new Product("Zen","Laptop","White",2022));
		service.addProduct(new Product("Sony","Laptop","Brown",2024));
		service.addProduct(new Product("LG","Laptop","Brown",2022));
		service.addProduct(new Product("MI","Laptop","Blue",2023));
		service.addProduct(new Product("Motorola","Laptop","Grey",2021));
		
//		List<Product> products= service.getAllProducts();
//		for (Product product : products) {
//			System.out.println(product);
//		}
//		
//		Product p = service.getProduct("Mac");
//		System.out.println(p);
//		
//		List<Product> prods= service.findProductsByPlace("Brown");
//			for (Product product : prods) {
//				System.out.println(product);
//			}
//			
//		List<Product> pList=service.productsOutOfWarranty();
//		for (Product product : pList) {
//		System.out.println(product);
//		}
		
//		List<Product> productlList= service.getProductWithText("black");
//		for (Product product : productlList) {
//			System.out.println(product);
//		}
	}
}
