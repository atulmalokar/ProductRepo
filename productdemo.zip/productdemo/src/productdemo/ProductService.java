package productdemo;

import java.util.ArrayList;
import java.util.List;

public class ProductService {

	List<Product> products = new ArrayList<>();
	ProductDB db = new ProductDB();
	public void addProduct(Product p) {
//		products.add(p);
		db.save(p);
		
	}


	public List<Product> getAllProducts() {

		return db.getAll();
	}


	public Product getProduct(String name) {
		for (Product product : products) {
			if(product.getName().equals(name))
				return product;
		}
		return null;
	}


	public List<Product> findProductsByPlace(String place) {
		List<Product> result = new ArrayList<>();
		for(Product product : products) {
			if(product.getPlace().equals(place))
				 result.add(product);
		}
		return result;
		
	}


	public List<Product> productsOutOfWarranty() {
		List<Product>list= new ArrayList<>();
		for(Product product:products)
			if(product.getWarranty() < 2023)
		list.add(product);
		return list;
	}


	public List<Product> getProductWithText(String text) {
		String str = text.toLowerCase();
		List<Product> list = new ArrayList<>();
		
		for (Product product : products) {
			String name = product.getName().toLowerCase();
			String type = product.getType().toLowerCase();
			String place = product.getPlace().toLowerCase();
			
			if(name.contains(str) || type.contains(str) || place.contains(str))
				list.add(product);
		}
		return list;
	}
	
	
}
