package com.telusko.product;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ProductService {
	
	@Autowired
	ProductDB db;

//
//	public void addProduct(Product p) {
////		products.add(p);
//		db.save(p);
//
//	}

	public List<Product> getAllProducts() {

		return db.findAll();
	}

//	public Product getProduct(String name) {
//		for (Product product : products) {
//			if (product.getName().equals(name))
//				return product;
//		}
//		return null;
//	}
//
//	public List<Product> findProductsByPlace(String place) {
//		List<Product> result = new ArrayList<>();
//		for (Product product : products) {
//			if (product.getPlace().equals(place))
//				result.add(product);
//		}
//		return result;
//
//	}
//
//	public List<Product> productsOutOfWarranty() {
//		List<Product> list = new ArrayList<>();
//		for (Product product : products)
//			if (product.getWarranty() < 2023)
//				list.add(product);
//		return list;
//	}
}
